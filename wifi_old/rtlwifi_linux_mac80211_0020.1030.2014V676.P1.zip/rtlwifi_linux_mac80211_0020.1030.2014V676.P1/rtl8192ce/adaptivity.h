/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/
 
#ifndef	__ODMDIG_H__
#define __ODMDIG_H__

#include "../wifi.h"

#define u64 unsigned long long
#define	MASK_BYTE0 0xff
#define	MASK_BYTE1 0xff00
#define	MASK_BYTE2 0xff0000
#define	MASK_BYTE3 0xff000000
#define	MASKDWORD 0xffffffff

#define		DM_DIG_MAX_NIC				0x3e
#define		DM_DIG_MIN_NIC				0x1e //0x22//0x1c
#define		DM_DIG_MAX_OF_MIN_NIC		0x3e

#define		DM_DIG_THRESH_HIGH	40
#define		DM_DIG_THRESH_LOW	35
#define		DM_DIG_MAX_NIC_HP	0x46
#define		DM_DIG_MIN_NIC_HP	0x2e
#define		DM_DIG_MAX_AP_HP	0x42
#define		DM_DIG_MIN_AP_HP	0x30
#define		DM_DIG_FA_TH0		0x200
#define		DM_DIG_FA_TH1		0x300
#define		DM_DIG_FA_TH2		0x400
#define		DM_DIG_BACKOFF_MAX	12
#define		DM_DIG_BACKOFF_M	-4
#define		DM_DIG_BACKOFF_DEFAULT		10
#define 	DM_DIG_FA_TH0_LPS	4
#define 	DM_DIG_FA_TH1_LPS	15
#define 	DM_DIG_FA_TH2_LPS	30
#define 	RSSI_OFFSET_DIG		0x05

#define		DM_DIG_MAX_AP					0x3e
#define		DM_DIG_MIN_AP					0x1c
#define		DM_DIG_MIN_AP_DFS				0x20



//BB REG LIST
//PAGE 8
#define	ODM_REG_BB_CTRL_11N				0x800
#define	ODM_REG_RF_PIN_11N				0x804
#define	ODM_REG_PSD_CTRL_11N				0x808
#define	ODM_REG_TX_ANT_CTRL_11N			0x80C
#define	ODM_REG_BB_PWR_SAV5_11N			0x818
#define	ODM_REG_CCK_RPT_FORMAT_11N		0x824
#define	ODM_REG_CCK_RPT_FORMAT_11N_B	0x82C
#define	ODM_REG_RX_DEFUALT_A_11N		0x858
#define	ODM_REG_RX_DEFUALT_B_11N		0x85A
#define	ODM_REG_BB_PWR_SAV3_11N			0x85C
#define	ODM_REG_ANTSEL_CTRL_11N			0x860
#define	ODM_REG_RX_ANT_CTRL_11N			0x864
#define	ODM_REG_PIN_CTRL_11N				0x870
#define	ODM_REG_BB_PWR_SAV1_11N			0x874
#define	ODM_REG_ANTSEL_PATH_11N			0x878
#define	ODM_REG_BB_3WIRE_11N			0x88C
#define	ODM_REG_SC_CNT_11N				0x8C4
#define	ODM_REG_PSD_DATA_11N			0x8B4
#define	ODM_REG_NHM_TIMER_11N			0x894
#define	ODM_REG_NHM_TH9_TH10_11N		0x890
#define	ODM_REG_NHM_TH3_TO_TH0_11N		0x898
#define	ODM_REG_NHM_TH7_TO_TH4_11N		0x89c
#define	ODM_REG_NHM_CNT_11N				0x8d8


#define	ODM_REG_RPT_11N					0xDF4
#define	ODM_REG_FPGA0_IQK_11N			0xE28
#define	ODM_REG_OFDM_FA_RSTC_11N		0xC0C



#define		rOFDM0_ECCAThreshold		0xc4c // energy CCA
#define		rOFDM0_XAAGCCore1			0xc50	// DIG
#define		rOFDM0_XAAGCCore2			0xc54
#define		rOFDM0_XBAGCCore1			0xc58
#define		rOFDM0_XBAGCCore2			0xc5c
#define		rOFDM0_XCAGCCore1			0xc60
#define		rOFDM0_XCAGCCore2			0xc64
#define		rOFDM0_XDAGCCore1			0xc68
#define		rOFDM0_XDAGCCore2			0xc6c



#define	ODM_REG_DBG_RPT_11N				0x908


//-----------------------------------------------------
//
//	0x0500h ~ 0x05FFh	EDCA Configuration
//
//-----------------------------------------------------
#define REG_EDCA_VO_PARAM			0x0500
#define REG_EDCA_VI_PARAM			0x0504
#define REG_EDCA_BE_PARAM			0x0508
#define REG_EDCA_BK_PARAM			0x050C
#define REG_BCNTCFG				0x0510
#define REG_PIFS						0x0512
#define REG_RDG_PIFS				0x0513
#define REG_SIFS_CTX				0x0514
#define REG_SIFS_TRX				0x0516
#define REG_TSFTR_SNC_OFFSET			0x0518
#define REG_AGGR_BREAK_TIME			0x051A
#define REG_SLOT						0x051B
#define REG_TX_PTCL_CTRL			0x0520
#define REG_TXPAUSE				0x0522
#define REG_DIS_TXREQ_CLR			0x0523
#define REG_RD_CTRL				0x0524


#define	ODM_REG_IGI_A_11N				0xC50
#define	ODM_REG_IGI_B_11N					0xC58
#define	ODM_REG_IGI_C_11N					0xF84
#define	ODM_REG_IGI_D_11N					0xF88
#define	ODM_BIT_IGI_11N					0x0000007F
#define	ODM_BIT_CCK_RPT_FORMAT_11N		BIT9
#define	ODM_BIT_BB_RX_PATH_11N			0xF


//PAGE D
#define	ODM_REG_OFDM_FA_RSTD_11N		0xD00
#define	ODM_REG_OFDM_FA_TYPE2_11N		0xDA0
#define	ODM_REG_OFDM_FA_TYPE3_11N		0xDA4
#define	ODM_REG_OFDM_FA_TYPE4_11N		0xDA8
#define	ODM_REG_RPT_11N					0xDF4


#define	ODM_REG_OFDM_FA_HOLDC_11N		0xC00
#define	ODM_REG_OFDM_FA_TYPE1_11N		0xCF0
#define	ODM_REG_CCK_FA_RST_11N			0xA2C
#define	ODM_REG_CCK_FA_MSB_11N			0xA58
#define	ODM_REG_CCK_FA_LSB_11N			0xA5C
#define	ODM_REG_CCK_CCA_CNT_11N			0xA60
#define	ODM_REG_BB_PWR_SAV4_11N			0xA74

#define	ODM_REG_CCK_CCA_11N				0xA0A


#define ODM_CMNINFO_ABILITY 1



enum board_type {
	ODM_BOARD_DEFAULT = 0,	  /* The DEFAULT case. */
	ODM_BOARD_MINICARD = BIT(0), /* 0 = non-mini card, 1 = mini card. */
	ODM_BOARD_SLIM = BIT(1), /* 0 = non-slim card, 1 = slim card */
	ODM_BOARD_BT = BIT(2), /* 0 = without BT card, 1 = with BT */
	ODM_BOARD_EXT_PA = BIT(3), /* 1 = existing 2G ext-PA */
	ODM_BOARD_EXT_LNA = BIT(4), /* 1 = existing 2G ext-LNA */
	ODM_BOARD_EXT_TRSW = BIT(5), /* 1 = existing ext-TRSW */
	ODM_BOARD_EXT_PA_5G = BIT(6), /* 1 = existing 5G ext-PA */
	ODM_BOARD_EXT_LNA_5G = BIT(7), /* 1 = existing 5G ext-LNA */
};

/*tag_dynamic_init_gain_operation_type_definition*/
typedef enum tag_dig_otd
{
	DIG_TYPE_THRESH_HIGH	= 0,
	DIG_TYPE_THRESH_LOW	= 1,
	DIG_TYPE_BACKOFF		= 2,
	DIG_TYPE_RX_GAIN_MIN	= 3,
	DIG_TYPE_RX_GAIN_MAX	= 4,
	DIG_TYPE_ENABLE 		= 5,
	DIG_TYPE_DISABLE 		= 6,	
	DIG_OP_TYPE_MAX
}DM_DIG_OP_E;




typedef enum tag_pause_dig_type {
	ODM_PAUSE_DIG    		= 	BIT(0),
	ODM_RESUME_DIG  		= 	BIT(1)
} odm_pause_dig_type;

typedef enum tag_pause_cckpd_type {
	ODM_PAUSE_CCKPD    	= 	BIT(0),
	ODM_RESUME_CCKPD  	= 	BIT(1)
} ODM_Pause_CCKPD_TYPE;

typedef enum tag_trx_mux_type
{
	ODM_SHUTDOWN			= 0,
	ODM_STANDBY_MODE		= 1,
	ODM_TX_MODE			= 2,
	ODM_RX_MODE			= 3
}trx_mux_type;

typedef enum tag_macedcca_type
{
	ODM_IGNORE_EDCCA			= 0,
	ODM_DONT_IGNORE_EDCCA	= 1
}mac_edcca_type;

typedef enum support_ability_definition
{
	// BB ODM section BIT 0-15
	ODM_BB_DIG					= BIT(0),
	ODM_BB_RA_MASK				= BIT(1),
	ODM_BB_DYNAMIC_TXPWR		= BIT(2),
	ODM_BB_FA_CNT				= BIT(3),
	ODM_BB_RSSI_MONITOR			= BIT(4),
	ODM_BB_CCK_PD				= BIT(5),
	ODM_BB_ANT_DIV				= BIT(6),
	ODM_BB_PWR_SAVE				= BIT(7),
	ODM_BB_PWR_TRAIN			= BIT(8),
	ODM_BB_RATE_ADAPTIVE		= BIT(9),
	ODM_BB_PATH_DIV				= BIT(10),
	ODM_BB_PSD					= BIT(11),
	ODM_BB_RXHP					= BIT(12),
	ODM_BB_ADAPTIVITY			= BIT(13),
	ODM_BB_DYNAMIC_ATC			= BIT(14),
	// MAC DM section BIT 16-23
	ODM_MAC_EDCA_TURBO			= BIT(16),
	ODM_MAC_EARLY_MODE			= BIT(17),
	// RF ODM section BIT 24-31
	ODM_RF_TX_PWR_TRACK			= BIT(24),
	ODM_RF_RX_GAIN_TRACK		= BIT(25),
	ODM_RF_CALIBRATION			= BIT(26),
}ODM_ABILITY_E;

/*dynamic_initial_gain_threshold*/
/*
typedef struct dig_t
{
	bool stop_dig;
	bool psd_in_progress;

	u8	dig_enable_flag;

	int	rssi_lowthresh;
	int	rssi_highthresh;

	u32		fa_low_thresh;//useless
	u32		fa_high_thresh;//useless
	u8		cur_ig_value;
	u8		bt30_cur_igi;
	u8		igi_backup;

	s8		backoff_val;//useless
	s8		backoff_val_range_max;//useless
	s8		backoff_val_range_min;//useless
	u8		rx_gain_range_max;
	u8		rx_gain_range_min;

	u8		pre_cck_cca_thres;//useless
	u8		cur_cck_cca_thres;
	u8		cck_pd_backup;

	u8		large_fa_hit;
	u8		forbidden_igi;
	u32		recover_cnt;

	u8		dig_dynamic_min_0;
	u8		dig_dynamic_min_1;
	bool		media_connect_0;
	bool		media_connect_1;

	u32		antdiv_rssi_max;

	u8		*p2p_link_in_progress;//todo:notice this val
}dig_t;
*/

typedef struct adaptivity_t{
	u32 support_ability;
	bool adaptivity_flag;
	u8 tolerance_cnt;
	u32 nhm_cur_tx_ok_cnt;
	u32 nhm_cur_rx_ok_cnt;
	u8 nhm_wait;
	u16 nhm_cnt_0;
	u16 nhm_cnt_1;
	s8 h2l_lb;
	s8 l2h_lb;
	u8 adaptivity_igi_upper;
	bool first_link;
	bool check;
	bool edcca_enable_state;
	bool nhm_enable;
	bool ada_on;
	//bool linked;/*wifi is linked*/
	u8 th_edcca_hl_diff;
	bool force_edcca;
	u8 adap_en_rssi;
	bool pre_edcca_enable;
	bool dm_initial_gain_enable;
	
	u8 th_l2h_ini;
	u8 th_edcca_hl_dif;
	s8 igi_base;
	u8 igi_target;
	u8 rssi_min;
	u8 igi_lower_bound;
	
	
	/*todo*/
	u8 bt_hs_operation;
	bool bt_connect_process;	// BT HS is under connection progress.
	u8 bt_hs_rssi;				// BT HS mode wifi rssi value.

	
}adaptivity_t;




void dm_nhm_counter_statistics(struct ieee80211_hw *hw);
void dm_change_dynamic_init_gain_thresh(struct ieee80211_hw *hw,u32	dm_type,u32	dm_value);
void dm_check_environment(struct ieee80211_hw *hw);
void dm_mac_edcca_state(struct ieee80211_hw *hw,mac_edcca_type state);
void dm_get_nhm_counter_statistics(struct ieee80211_hw *hw);
void dm_nhm_counter_statistics_reset(struct ieee80211_hw *hw);
void dm_nhm_bb_init(struct ieee80211_hw *hw);
bool dm_cal_nhm_cnt(struct ieee80211_hw *hw);
void dm_nhm_bb(struct ieee80211_hw *hw);
void dm_set_edcca_threshold(struct ieee80211_hw *hw,s8	h2l,s8	l2h);
void dm_set_trx_mux(struct ieee80211_hw *hw,trx_mux_type tx_mode,trx_mux_type rx_mode);
void dm_search_pw_db_lower_bound(struct ieee80211_hw *hw);
void dm_adaptivity_init(struct ieee80211_hw *hw);
void dm_enable_edcca(struct ieee80211_hw *hw);
void dm_disable_edcca(struct ieee80211_hw *hw);
void dm_dynamic_edcca(struct ieee80211_hw *hw);
bool dm_adaptivity_main(struct ieee80211_hw *hw,u8 igi);
int dm_get_igi_for_diff(int value_igi);
void dm_write_dig(struct ieee80211_hw *hw,u8	current_igi);
void dm_pause_dig(struct ieee80211_hw *hw,odm_pause_dig_type pause_type,u8 igi_value);
bool dm_dig_abort(struct ieee80211_hw *hw);
void dm_dig_init(struct ieee80211_hw *hw);
void dm_dig(struct ieee80211_hw *hw);
void dm_dig_by_rssi_lps(struct ieee80211_hw *hw);
void dig_for_bt_hs_mode(struct ieee80211_hw *hw);
void fa_threshold_check(struct ieee80211_hw *hw,bool dfs_band,bool performance,u32 rx_tp,u32 tx_tp,u32* dm_fa_thres);
u8 forbidden_igi_check(struct ieee80211_hw *hw,u8	dig_dynamic_min,u8	current_igi);
void dm_in_band_noise_calculate (struct ieee80211_hw *hw);
void dm_false_alarm_counter_statistics(struct ieee80211_hw *hw);
void dm_pause_cck_packet_detection(struct ieee80211_hw *hw,ODM_Pause_CCKPD_TYPE	pause_type,u8 CCKPDThreshold);
void dm_cck_packet_detection_thresh(struct ieee80211_hw *hw);
void dm_write_cck_cca_thres(struct ieee80211_hw *hw,u8 cur_cck_cca_thres);
void  dm_cmn_info_update(struct ieee80211_hw *hw,u32 cmn_info,u32 value);
void dm_reset_fa_counter_92c(struct ieee80211_hw *hw);


extern adaptivity_t *dm_adaptivity;




#endif
