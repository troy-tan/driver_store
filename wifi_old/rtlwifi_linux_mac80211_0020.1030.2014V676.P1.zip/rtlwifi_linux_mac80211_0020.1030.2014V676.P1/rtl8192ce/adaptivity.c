/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/

 
 
 

/*
todo :
1.add bt operation notify
2.regd info passed from system,not the driver
*/


#include "dm.h"
#include "../regd.h"
#include "adaptivity.h"


/*porting from windows team WinBlue 30265*/
#define ADAPTIVITY_VERSION "7.0"



/*config definition*/
bool RegDmLinkAdaptivity = false;
bool RegEnableCarrierSense = false;
bool RegNHMEnable = false;
int RegEnableAdaptivity = 0;
//#define ENABLE_ADAPTIVITY



adaptivity_t adaptivity_entity;
adaptivity_t *dm_adaptivity = &adaptivity_entity;


void dm_change_dynamic_init_gain_thresh(struct ieee80211_hw *hw,u32	dm_type,u32	dm_value)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	if (dm_type == DIG_TYPE_THRESH_HIGH) {
		dm_digtable->rssi_highthresh = dm_value;		
	} else if (dm_type == DIG_TYPE_THRESH_LOW) {
		dm_digtable->rssi_lowthresh = dm_value;
	} else if (dm_type == DIG_TYPE_ENABLE) {
		dm_digtable->dig_enable_flag	= true;
	} else if (dm_type == DIG_TYPE_DISABLE) {
		dm_digtable->dig_enable_flag = false;
	} else if (dm_type == DIG_TYPE_BACKOFF) {
		if(dm_value > 30)
			dm_value = 30;
		dm_digtable->back_val = (u8)dm_value;
	} else if(dm_type == DIG_TYPE_RX_GAIN_MIN) {
		if(dm_value == 0)
			dm_value = 0x1;
		dm_digtable->rx_gain_min = (u8)dm_value;
	} else if(dm_type == DIG_TYPE_RX_GAIN_MAX) {
		if(dm_value > 0x50)
			dm_value = 0x50;
		dm_digtable->rx_gain_max = (u8)dm_value;
	}
}

void dm_check_adaptity(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);

	if(dm_adaptivity->support_ability & ODM_BB_ADAPTIVITY) {
		if(dm_adaptivity->ada_on == true) {
			if(RegDmLinkAdaptivity == true) {
				if(rtlpriv->mac80211.link_state == MAC80211_LINKED && dm_adaptivity->check == false) {
					dm_nhm_counter_statistics(hw);
					dm_check_environment(hw);
				} else if(rtlpriv->mac80211.link_state != MAC80211_LINKED) {
					dm_adaptivity->check = false;
				}
			} else {
				dm_mac_edcca_state(hw, ODM_DONT_IGNORE_EDCCA);
				dm_adaptivity->adaptivity_flag = true;
			}
		} else {
			dm_mac_edcca_state(hw, ODM_IGNORE_EDCCA);
			dm_adaptivity->adaptivity_flag = false;
		}
	}
}

void dm_check_environment(struct ieee80211_hw *hw)
{
	bool 	clean_environment = false;
	if(dm_adaptivity->first_link == true)
	{
		dm_adaptivity->adaptivity_flag = true;
		dm_adaptivity->first_link = false;
		return;
	} else {
		// Start enter NHM after 4 nhm_wait
		if(dm_adaptivity->nhm_wait < 3) {
			dm_adaptivity->nhm_wait ++;
			dm_nhm_counter_statistics(hw);
			return;
		} else {
			dm_nhm_counter_statistics(hw);
			clean_environment = dm_cal_nhm_cnt(hw);
			if(clean_environment == true) {
				dm_mac_edcca_state(hw, ODM_DONT_IGNORE_EDCCA);
				dm_adaptivity->adaptivity_flag = true;
			} else {
				dm_mac_edcca_state(hw, ODM_IGNORE_EDCCA);
				dm_adaptivity->adaptivity_flag = false;
			}
			dm_adaptivity->first_link = true;
			dm_adaptivity->check = true;
		}
	}
}


void dm_get_nhm_counter_statistics(struct ieee80211_hw *hw)
{
	u32		value32 = 0;
	
	value32 = rtl_get_bbreg(hw, ODM_REG_NHM_CNT_11N, MASKDWORD);
	dm_adaptivity->nhm_cnt_0 = (u8)(value32 & MASK_BYTE0);
	dm_adaptivity->nhm_cnt_1 = (u8)((value32 & MASK_BYTE1)>>8);

}


void dm_nhm_counter_statistics(struct ieee80211_hw *hw)
{
	// Get NHM report
	dm_get_nhm_counter_statistics(hw);
	// Reset NHM counter
	dm_nhm_counter_statistics_reset(hw);
}


void dm_nhm_counter_statistics_reset(struct ieee80211_hw *hw)
{
	rtl_set_bbreg(hw, ODM_REG_NHM_TH9_TH10_11N, BIT(1), 0);
	rtl_set_bbreg(hw, ODM_REG_NHM_TH9_TH10_11N, BIT(1), 1);
}


// for NHM 8812AU test
void dm_nhm_bb_init(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);


	dm_adaptivity->adaptivity_flag = 0;
	dm_adaptivity->tolerance_cnt = 3;
	dm_adaptivity->nhm_cur_tx_ok_cnt = 0;
	dm_adaptivity->nhm_cur_rx_ok_cnt = 0;


	//PHY parameters initialize for n series
	//0x894[31:16]=0x2710	Time duration for NHM unit: 4us, 0x2710=40ms
	rtl_write_word(rtlpriv,ODM_REG_NHM_TIMER_11N+2,0xc350);
	//ODM_Write2Byte(dm_adaptivity, ODM_REG_NHM_TIMER_11N+2, 0x4e20);	//0x894[31:16]=0x4e20	Time duration for NHM unit: 4us, 0x4e20=80ms
	
	//0x890[31:16]=0xffff	th_9, th_10
	rtl_write_word(rtlpriv,ODM_REG_NHM_TH9_TH10_11N+2,0xffff);

	//ODM_Write4Byte(dm_adaptivity, ODM_REG_NHM_TH3_TO_TH0_11N, 0xffffff5c);	//0x898=0xffffff5c 		th_3, th_2, th_1, th_0

	rtl_write_dword(rtlpriv,ODM_REG_NHM_TH3_TO_TH0_11N,0xffffff50);
	rtl_write_dword(rtlpriv,ODM_REG_NHM_TH7_TO_TH4_11N,0xffffffff);

	
	rtl_set_bbreg(hw, ODM_REG_FPGA0_IQK_11N,MASK_BYTE0, 0xff);//0xe28[7:0]=0xff		th_8
	//ODM_SetBBReg(dm_adaptivity, ODM_REG_NHM_TH9_TH10_11N, BIT10|BIT9|BIT8, 7);	//0x890[9:8]=3			enable CCX
	
	rtl_set_bbreg(hw, ODM_REG_NHM_TH9_TH10_11N, BIT(10)|BIT(9)|BIT(8), 0x1);//0x890[10:8]=1		ignoreCCA ignore PHYTXON	enable CCX
	rtl_set_bbreg(hw, ODM_REG_OFDM_FA_RSTC_11N, BIT(7), 1);//0xc0c[7]=1			max power among all RX ants		

	dm_nhm_counter_statistics_reset(hw);

}

bool dm_cal_nhm_cnt(struct ieee80211_hw *hw)
{

	u16			base = 0;

	base = dm_adaptivity->nhm_cnt_0 + dm_adaptivity->nhm_cnt_1;

	if(base != 0)
	{
		dm_adaptivity->nhm_cnt_0 = ((dm_adaptivity->nhm_cnt_0) << 8) / base;
		dm_adaptivity->nhm_cnt_1 = ((dm_adaptivity->nhm_cnt_1) << 8) / base;
	}
	if((dm_adaptivity->nhm_cnt_0 - dm_adaptivity->nhm_cnt_1) >= 100)
		return true;/*clean environment*/
	else
		return false;/*noisy environment*/

}


void dm_nhm_bb(struct ieee80211_hw *hw)
{

	struct rtl_priv *rtlpriv = rtl_priv(hw);


	bool clean_environment;
	dm_nhm_counter_statistics(hw);
	clean_environment = dm_cal_nhm_cnt(hw);

	dm_adaptivity->nhm_cur_tx_ok_cnt = rtlpriv->link_info.num_tx_packets_unicast;
	dm_adaptivity->nhm_cur_rx_ok_cnt = rtlpriv->link_info.num_rx_packets_unicast;
	
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity->nhm_cur_tx_ok_cnt=%d\n",dm_adaptivity->nhm_cur_tx_ok_cnt);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity->nhm_cur_rx_ok_cnt=%d\n",dm_adaptivity->nhm_cur_rx_ok_cnt);


	
	if ( ((dm_adaptivity->nhm_cur_tx_ok_cnt>>10) > 2) && ((dm_adaptivity->nhm_cur_tx_ok_cnt) + 1 > ((dm_adaptivity->nhm_cur_rx_ok_cnt<<2) + 1)))		
	//Tx > 4*Rx and Tx > 2Mb possible for dm_adaptivity test	
	//Tx > 4*Rx possible for dm_adaptivity test
	{
		if(clean_environment == true || dm_adaptivity->adaptivity_flag == true)
		{
			//Enable EDCCA since it is possible running Adaptivity testing
			dm_adaptivity->adaptivity_flag = true;
			dm_mac_edcca_state(hw, ODM_DONT_IGNORE_EDCCA);
			dm_adaptivity->tolerance_cnt = 0;
		} else {
			if(dm_adaptivity->tolerance_cnt<3)
				dm_adaptivity->tolerance_cnt = dm_adaptivity->tolerance_cnt + 1;
			else {
				dm_mac_edcca_state(hw, ODM_IGNORE_EDCCA);
				dm_adaptivity->adaptivity_flag = false;
			}
		}
	}
	else {	// TX<RX 
		if(dm_adaptivity->adaptivity_flag == true && clean_environment == false)
		{
			dm_mac_edcca_state(hw, ODM_DONT_IGNORE_EDCCA);
			dm_adaptivity->tolerance_cnt = 0;
		}
		else
		{
			if(dm_adaptivity->tolerance_cnt<3)
				dm_adaptivity->tolerance_cnt = dm_adaptivity->tolerance_cnt + 1;
			else
			{
				dm_mac_edcca_state(hw, ODM_IGNORE_EDCCA);
            			dm_adaptivity->adaptivity_flag = false;
			}
		}
	}
	 
	 RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"adaptivity_flag = %d\n", dm_adaptivity->adaptivity_flag);


}

void dm_set_edcca_threshold(struct ieee80211_hw *hw,s8	h2l,s8	l2h)
{
	rtl_set_bbreg(hw, rOFDM0_ECCAThreshold, MASK_BYTE0, (u8)l2h);
	rtl_set_bbreg(hw, rOFDM0_ECCAThreshold, MASK_BYTE2, (u8)h2l);
}

void dm_set_trx_mux(struct ieee80211_hw *hw,trx_mux_type tx_mode,trx_mux_type rx_mode)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct rtl_phy *rtlphy = &(rtlpriv->phy);

	// set TXmod to standby mode to remove outside noise affect
	rtl_set_bbreg(hw, ODM_REG_CCK_RPT_FORMAT_11N, BIT(3)|BIT(2)|BIT(1), tx_mode);
	// set RXmod to standby mode to remove outside noise affect
	rtl_set_bbreg(hw, ODM_REG_CCK_RPT_FORMAT_11N, BIT(22)|BIT(21)|BIT(20), rx_mode);
	if(rtlphy->rf_type > RF_1T1R)
	{
		// set TXmod to standby mode to remove outside noise affect
		rtl_set_bbreg(hw, ODM_REG_CCK_RPT_FORMAT_11N_B, BIT(3)|BIT(2)|BIT(1), tx_mode);
		// set RXmod to standby mode to remove outside noise affect
		rtl_set_bbreg(hw, ODM_REG_CCK_RPT_FORMAT_11N_B, BIT(22)|BIT(21)|BIT(20), rx_mode);
	}
}

void dm_mac_edcca_state(struct ieee80211_hw *hw,mac_edcca_type state)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	if(state == ODM_IGNORE_EDCCA) {
	
		rtl_set_bbreg(hw, REG_TX_PTCL_CTRL, BIT(15), 1);//ignore EDCCA	reg520[15]=1
		rtl_set_bbreg(hw, REG_RD_CTRL, BIT(11), 0);//reg524[11]=0
		
	} else {// don't set MAC ignore EDCCA signal

		rtl_set_bbreg(hw, REG_TX_PTCL_CTRL, BIT(15), 0);//don't ignore EDCCA	 reg520[15]=0
		rtl_set_bbreg(hw, REG_RD_CTRL, BIT(11), 1);//reg524[11]=1	
	}

	dm_adaptivity->edcca_enable_state = state;
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"EDCCA enable state = %d \n", state);


}


void dm_search_pw_db_lower_bound(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	u32 value32 =0;
	u8 cnt, igi_pause = 0x7f, igi_resume = 0x20, igi = 0x50;	//igi = 0x50 for cal EDCCA lower bound
	u8 tx_edcca1 = 0, tx_edcca0 = 0;
	bool adjust = true;
	s8 th_l2h_dmc, th_h2l_dmc, igi_target = 0x32;
	//s8 th_l2h, th_h2l, 
	s8 diff;

	dm_set_trx_mux(hw, ODM_STANDBY_MODE, ODM_STANDBY_MODE);
	dm_pause_dig(hw, ODM_PAUSE_DIG, igi_pause);

	diff = igi_target -(s8)igi;
	th_l2h_dmc = dm_adaptivity->th_l2h_ini + diff;
		if(th_l2h_dmc > 10) 	
			th_l2h_dmc = 10;
	th_h2l_dmc = th_l2h_dmc - dm_adaptivity->th_edcca_hl_diff;

	dm_set_edcca_threshold(hw, th_h2l_dmc, th_l2h_dmc);			
	mdelay(5);

	while(adjust)
	{
		for(cnt=0; cnt<20; cnt ++)
		{
			value32 = rtl_get_bbreg(hw, ODM_REG_RPT_11N, MASKDWORD);
			if(value32 & BIT(29))
				tx_edcca1 = tx_edcca1 + 1;
			else
				tx_edcca0 = tx_edcca0 + 1;
		}
		//DbgPrint("tx_edcca1 = %d, tx_edcca0 = %d\n", dm_adaptivity->tx_edcca1, dm_adaptivity->tx_edcca0);
	
		if(tx_edcca1 > 9)
		{
			igi = igi -1;
			th_l2h_dmc = th_l2h_dmc + 1;
				if(th_l2h_dmc > 10)
					th_l2h_dmc = 10;
			th_h2l_dmc = th_l2h_dmc - dm_adaptivity->th_edcca_hl_diff;

			dm_set_edcca_threshold(hw, th_h2l_dmc, th_l2h_dmc);

			tx_edcca1 = 0;
			tx_edcca0 = 0;

			if(th_l2h_dmc == 10)
			{
				adjust = false;
				dm_adaptivity->h2l_lb = th_h2l_dmc;
				dm_adaptivity->l2h_lb = th_l2h_dmc;
				dm_adaptivity->adaptivity_igi_upper = igi;
			}
		}
		else
		{
			adjust = false;
			dm_adaptivity->h2l_lb = th_h2l_dmc;
			dm_adaptivity->l2h_lb = th_l2h_dmc;	
			dm_adaptivity->adaptivity_igi_upper = igi;
		}
	}
							


	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"igi = 0x%x, h2l_lb = 0x%x, l2h_lb = 0x%x\n", igi, dm_adaptivity->h2l_lb , dm_adaptivity->l2h_lb);
	
	
	dm_set_trx_mux(hw, ODM_TX_MODE, ODM_RX_MODE);
	dm_pause_dig(hw, ODM_RESUME_DIG, igi_resume);
	dm_set_edcca_threshold(hw, 0x7f, 0x7f); // resume to no link state
}

void dm_adaptivity_init(struct ieee80211_hw *hw)
{

	struct rtl_priv *rtlpriv = rtl_priv(hw);

	dm_adaptivity->support_ability = 	
#ifdef ENABLE_ADAPTIVITY
			ODM_BB_ADAPTIVITY |
#endif
			ODM_BB_DIG 				|	// For BB
			ODM_BB_RA_MASK			|
			ODM_BB_DYNAMIC_TXPWR	|
			ODM_BB_FA_CNT			|
			ODM_BB_RSSI_MONITOR		|
			ODM_BB_CCK_PD			|
			ODM_BB_PWR_SAVE			|
			ODM_BB_RXHP			|
			ODM_RF_TX_PWR_TRACK		|	// For RF
			ODM_RF_RX_GAIN_TRACK	|
			ODM_RF_CALIBRATION		|
			ODM_MAC_EDCA_TURBO		|	// For MAC
			ODM_MAC_EARLY_MODE	|
			ODM_BB_DYNAMIC_ATC;


	if(RegEnableCarrierSense == false)
		dm_adaptivity->th_l2h_ini = 0xf5; // -7
	else
		dm_adaptivity->th_l2h_ini = 0xa;

	dm_adaptivity->nhm_enable = RegNHMEnable;		// for NHM enable
	dm_adaptivity->th_edcca_hl_diff = 7;


	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"th_l2h_ini = 0x%x, th_edcca_hl_diff = 0x%x\n", dm_adaptivity->th_l2h_ini, dm_adaptivity->th_edcca_hl_dif);
	
	dm_adaptivity->bt_connect_process = false;
	dm_adaptivity->igi_base = 0x32;	
	dm_adaptivity->igi_target = 0x1c;
	dm_adaptivity->force_edcca = 0;
	dm_adaptivity->adap_en_rssi = 20;
	dm_adaptivity->h2l_lb= 0;
	dm_adaptivity->l2h_lb= 0;
	dm_adaptivity->adaptivity_igi_upper = 0;
	dm_adaptivity->nhm_wait = 0;
	dm_adaptivity->check = false;
	dm_adaptivity->first_link = true;
	dm_adaptivity->ada_on = true;
	dm_nhm_bb_init(hw);

	rtl_set_bbreg(hw, REG_RD_CTRL, BIT(11), 1);// stop counting if EDCCA is asserted
	//Search pwdB lower bound
	rtl_set_bbreg(hw, ODM_REG_DBG_RPT_11N, MASKDWORD, 0x208);

	dm_search_pw_db_lower_bound(hw);
	dm_mac_edcca_state(hw, ODM_IGNORE_EDCCA);
}

// Add by Neil Chen to enable edcca to MP Platform 

void dm_enable_edcca(struct ieee80211_hw *hw)
{

	struct rtl_priv *rtlpriv = rtl_priv(hw);

	// This should be moved out of OUTSRC
	// Enable EDCCA. The value is suggested by SD3 Wilson.

	//
	// Revised for ASUS 11b/g performance issues, suggested by BB Neil, 2012.04.13.
	//

		//PlatformEFIOWrite1Byte(Adapter, rOFDM0_ECCAThreshold, 0x03);
		
	rtl_write_byte(rtlpriv, rOFDM0_ECCAThreshold, 0x03);
	rtl_write_byte(rtlpriv, rOFDM0_ECCAThreshold+2, 0x00);

	//PlatformEFIOWrite1Byte(Adapter, rOFDM0_ECCAThreshold+2, 0x00);
}

void dm_disable_edcca(struct ieee80211_hw *hw)
{	
	// Disable EDCCA..
	struct rtl_priv *rtlpriv = rtl_priv(hw);

	rtl_write_byte(rtlpriv, rOFDM0_ECCAThreshold, 0x7f);
	rtl_write_byte(rtlpriv, rOFDM0_ECCAThreshold+2, 0x7f);
}

//
// Description: According to initial gain value to determine to enable or disable EDCCA.
//
// Suggested by SD3 Wilson. Added by tynli. 2011.11.25.
//
void dm_dynamic_edcca(struct ieee80211_hw *hw)
{
	u8			reg_c50;
	//bool		edcca_enable = false;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct rtl_mac *mac = rtl_mac(rtlpriv);





	//
	// 2013/11/14 Ken According to BB team Jame's suggestion, we need to disable soft AP mode EDCCA.
	// 2014/01/08 MH For Miracst AP mode test. We need to disable EDCCA. Otherwise, we may stop
	// to send beacon in noisy environment or platform.
	//
	if(mac->opmode == NL80211_IFTYPE_AP)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"At least One Port as AP disable EDCCA\n");
		dm_disable_edcca(hw);
		if(dm_adaptivity->pre_edcca_enable)
			dm_disable_edcca(hw);
		dm_adaptivity->pre_edcca_enable = false;
		return;
	}


	reg_c50 = (u8)rtl_get_bbreg(hw, rOFDM0_XAAGCCore1, MASK_BYTE0) & 0x7f;

 	if(reg_c50 > 0x28)
	{
		if(!dm_adaptivity->pre_edcca_enable)
		{
			dm_enable_edcca(hw);
			dm_adaptivity->pre_edcca_enable = true;
		}
		
	}
	else if(reg_c50 < 0x25)
	{
		if(dm_adaptivity->pre_edcca_enable)
		{
			dm_disable_edcca(hw);
			dm_adaptivity->pre_edcca_enable = false;
		}
	}
}


bool dm_adaptivity_main(struct ieee80211_hw *hw,u8 igi)
{

	s8 th_l2h_dmc, th_h2l_dmc;
	//s8 th_l2h, th_h2l, 
	s8 diff, igi_target;
	//u32 value32;
	bool edcca_state = 0;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct rtl_hal *rtlhal = rtl_hal(rtlpriv);
	struct rtl_phy *rtlphy = &(rtlpriv->phy);
	struct rtl_regulatory *reg= &rtlpriv->regd;



	if(!(dm_adaptivity->support_ability & ODM_BB_ADAPTIVITY)) {

		
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Go to dm_dynamic_edcca() \n");
		dm_dynamic_edcca(hw);
		return false;
	}

	if(RegEnableAdaptivity== 2)
	{
		if(RegEnableCarrierSense == false)		// check domain Code for Adaptivity or CarrierSense
		{
			if ((rtlhal->current_bandtype == BAND_ON_5G) && 
				!(reg->country_code == COUNTRY_CODE_ETSI || reg->country_code == COUNTRY_CODE_GLOBAL_DOMAIN)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Adaptivity skip 5G domain\n");

				return false;
			} else if((rtlhal->current_bandtype == BAND_ON_2_4G) &&
				!(reg->country_code == COUNTRY_CODE_ETSI || reg->country_code == COUNTRY_CODE_GLOBAL_DOMAIN)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Adaptivity skip 2.4G domain \n");

				return false;
			} else if ((rtlhal->current_bandtype != BAND_ON_2_4G) && (rtlhal->current_bandtype != BAND_ON_5G)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Adaptivity neither 2G nor 5G band, return \n");

				return false;
			}
		} else {
			if ((rtlhal->current_bandtype == BAND_ON_5G) && 
				!(reg->country_code == COUNTRY_CODE_ETSI || reg->country_code == COUNTRY_CODE_GLOBAL_DOMAIN)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"CarrierSense skip 5G domain\n");

				return false;
			} else if((rtlhal->current_bandtype == BAND_ON_2_4G) &&
				!(reg->country_code == COUNTRY_CODE_ETSI || reg->country_code == COUNTRY_CODE_GLOBAL_DOMAIN)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"CarrierSense skip 2.4G domain\n");

				return false;
			
			} else if ((rtlhal->current_bandtype != BAND_ON_2_4G) && (rtlhal->current_bandtype != BAND_ON_5G)) {
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"CarrierSense neither 2G nor 5G band, return\n");

				return false;
			}
		}
	}
	
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity() =====> \n");
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"force_edcca=%d, igi_base=0x%x, th_l2h_ini = %d, th_edcca_hl_diff = %d, adap_en_rssi = %d\n", 
		dm_adaptivity->force_edcca, dm_adaptivity->igi_base, dm_adaptivity->th_l2h_ini, dm_adaptivity->th_edcca_hl_diff, dm_adaptivity->adap_en_rssi);



	if(rtlphy->current_chan_bw == HT_CHANNEL_WIDTH_20) //CHANNEL_WIDTH_20
		igi_target = dm_adaptivity->igi_base;
	else if(rtlphy->current_chan_bw == HT_CHANNEL_WIDTH_20_40)
		igi_target = dm_adaptivity->igi_base + 2;
	else if(rtlphy->current_chan_bw == HT_CHANNEL_WIDTH_80)
		igi_target = dm_adaptivity->igi_base + 2;
	else
		igi_target = dm_adaptivity->igi_base;
		

	dm_adaptivity->igi_target = (u8) igi_target;
	// Band4 -> for AP : mode2, for sd4 and sd7 : turnoff dm_adaptivity

	if(rtlphy->current_channel >= 149)
	{
		dm_set_edcca_threshold(hw, 0x7f, 0x7f);
		return false;
	}

	if(!dm_adaptivity->force_edcca)
	{
		if(dm_adaptivity->rssi_min > dm_adaptivity->adap_en_rssi)
			edcca_state = 1;
		else if(dm_adaptivity->rssi_min < (dm_adaptivity->adap_en_rssi - 5))
			edcca_state = 0;
	}
	else
		edcca_state = 1;

	if(RegEnableCarrierSense == false && dm_adaptivity->nhm_enable == true)
		dm_nhm_bb(hw);

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"BandWidth=%s, igi_target=0x%x, edcca_state=%d, edcca_enable_state = %d\n",
		(rtlphy->current_chan_bw == HT_CHANNEL_WIDTH_80)?"80M":
		((rtlphy->current_chan_bw == HT_CHANNEL_WIDTH_20_40)?"40M":"20M"), 
		igi_target, edcca_state, dm_adaptivity->edcca_enable_state);


	if(edcca_state == 1) {
		diff = igi_target -(s8)igi;
		th_l2h_dmc = dm_adaptivity->th_l2h_ini + diff;
		if(th_l2h_dmc > 10) 	
			th_l2h_dmc = 10;
				
		th_h2l_dmc = th_l2h_dmc - dm_adaptivity->th_edcca_hl_diff;

		//replace lower bound to prevent EDCCA always equal 1
			if(th_h2l_dmc < dm_adaptivity->h2l_lb)				
				th_h2l_dmc = dm_adaptivity->h2l_lb;
			if(th_l2h_dmc < dm_adaptivity->l2h_lb)
				th_l2h_dmc = dm_adaptivity->l2h_lb;
	} else {
		th_l2h_dmc = 0x7f;
		th_h2l_dmc = 0x7f;
	}

	
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"igi=0x%x, th_l2h_dmc = %d, th_h2l_dmc = %d, adaptivity_flg = %d\n", igi, th_l2h_dmc, th_h2l_dmc, dm_adaptivity->adaptivity_flag);

	dm_set_edcca_threshold(hw, th_h2l_dmc, th_l2h_dmc);
	return true;
}

int dm_get_igi_for_diff(int value_igi)
{
	#define ONERCCA_LOW_TH		0x30
	#define ONERCCA_LOW_DIFF	8

	if (value_igi < ONERCCA_LOW_TH) {
		if ((ONERCCA_LOW_TH - value_igi) < ONERCCA_LOW_DIFF)
			return ONERCCA_LOW_TH;
		else
			return value_igi + ONERCCA_LOW_DIFF;
	} else {
		return value_igi;
	}
}

void dm_write_dig(struct ieee80211_hw *hw,u8	current_igi)
{
	//u8			IGIOffset_A = 0, IGIOffset_B = 0;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct rtl_phy *rtlphy = &(rtlpriv->phy);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	if(dm_digtable->stop_dig)
	{

		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Stop Writing igi\n");
		return;
	}

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"ODM_REG(IGI_A,dm_adaptivity)=0x%x, ODM_BIT(igi,dm_adaptivity)=0x%x \n",ODM_REG_IGI_A_11N,ODM_BIT_IGI_11N);

	if(dm_digtable->cur_igvalue != current_igi)
	{
		//1 Check initial gain by upper bound		
		if(!dm_digtable->psd_in_progress)
		{
			if(current_igi > dm_digtable->rx_gain_max)
			{

				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"current_igi(0x%02x) is larger than upper bound !!\n",dm_digtable->rx_gain_max);
				current_igi = dm_digtable->rx_gain_max;
			}
		}

		//1 Set igi value
		rtl_set_bbreg(hw, ODM_REG_IGI_A_11N, ODM_BIT_IGI_11N, current_igi);

		if(rtlphy->rf_type > RF_1T1R)
			rtl_set_bbreg(hw, ODM_REG_IGI_B_11N, ODM_BIT_IGI_11N, current_igi);

		dm_digtable->cur_igvalue = current_igi;
	}


	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"current_igi(0x%02x). \n",current_igi);

}

void dm_pause_dig(struct ieee80211_hw *hw,odm_pause_dig_type pause_type,u8 igi_value)
{
	static bool paused = false;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_pause_dig()=========>\n");

	if(dm_digtable->p2p_link_in_progress)
	{

		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"P2P in progress !!\n");
		return;
	}
	if(!paused && (!(dm_adaptivity->support_ability & ODM_BB_DIG) || !(dm_adaptivity->support_ability & ODM_BB_FA_CNT)))
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: support_ability ODM_BB_DIG or ODM_BB_FA_CNT is disabled\n");

		return;
	}
	
	switch(pause_type)
	{
		//1 Pause DIG
		case ODM_PAUSE_DIG:
			//2 Disable DIG
			dm_cmn_info_update(hw, ODM_CMNINFO_ABILITY, dm_adaptivity->support_ability & (~ODM_BB_DIG));
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Pause DIG !!\n");
			

			//2 Backup igi value
			if(!paused)
			{
				dm_digtable->igi_backup = dm_digtable->cur_igvalue;
				paused = true;
			}
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Backup igi  = 0x%x\n", dm_digtable->igi_backup);


			//2 Write new igi value
			dm_write_dig(hw, igi_value);
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Write new igi = 0x%x\n", igi_value);

			break;

		//1 Resume DIG
		case ODM_RESUME_DIG:
			if(paused)
			{
				//2 Write backup igi value
				dm_write_dig(hw, dm_digtable->igi_backup);
				paused = false;

				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Write original igi = 0x%x\n", dm_digtable->igi_backup);


				//2 Enable DIG
				dm_cmn_info_update(hw, ODM_CMNINFO_ABILITY, dm_adaptivity->support_ability | ODM_BB_DIG);	
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Resume DIG !!\n");

			}
			break;

		default:
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Wrong  type !!\n");
			break;
	}
}

bool dm_dig_abort(struct ieee80211_hw *hw)
{
	//pRXHP_T	pRX_HP_Table = &dm_adaptivity->DM_RXHP_Table;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	if(!(dm_adaptivity->support_ability & ODM_BB_FA_CNT))
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: support_ability ODM_BB_FA_CNT is disabled\n");
		return	true;
	}
	//support_ability
	if(!(dm_adaptivity->support_ability & ODM_BB_DIG))
	{	
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: support_ability ODM_BB_DIG is disabled\n");
		return	true;
	}
	//ScanInProcess
	if(rtlpriv->mac80211.act_scanning)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: In Scan Progress \n");
	    	return	true;
	}
	//add by Neil Chen to avoid PSD is processing
	if(dm_adaptivity->dm_initial_gain_enable == false)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: PSD is Processing \n");
		return	true;
	}

	if(dm_adaptivity->bt_hs_operation)
	{
		dig_for_bt_hs_mode(hw);
	}	

	return	false;
}

void dm_dig_init(struct ieee80211_hw *hw)
{	
	struct rtl_efuse *rtlefuse = rtl_efuse(rtl_priv(hw));
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	dm_digtable->stop_dig = false;
	dm_digtable->psd_in_progress = false;
	dm_digtable->cur_igvalue = (u8) rtl_get_bbreg(hw, ODM_REG_IGI_A_11N, ODM_BIT_IGI_11N);
	dm_digtable->rssi_lowthresh = DM_DIG_THRESH_LOW;
	dm_digtable->rssi_highthresh = DM_DIG_THRESH_HIGH;
	dm_digtable->fa_low_thresh	= DM_FALSEALARM_THRESH_LOW;
	dm_digtable->fa_high_thresh	= DM_FALSEALARM_THRESH_HIGH;
	dm_digtable->back_val = DM_DIG_BACKOFF_DEFAULT;
	dm_digtable->back_range_max = DM_DIG_BACKOFF_MAX;
	dm_digtable->back_range_min = DM_DIG_BACKOFF_MIN;
	dm_digtable->pre_cck_cca_thres = 0xFF;
	dm_digtable->cur_cck_cca_thres = 0x83;
	dm_digtable->forbidden_igi = DM_DIG_MIN_NIC;
	dm_digtable->large_fa_hit = 0;
	dm_digtable->recover_cnt = 0;
	dm_digtable->media_connect_0 = false;
	dm_digtable->media_connect_1 = false;
	//To Initialize dm_adaptivity->dm_initial_gain_enable == false to avoid DIG error
	dm_adaptivity->dm_initial_gain_enable = true;
	dm_digtable->dig_dynamic_min_0 = DM_DIG_MIN_NIC;
	dm_digtable->dig_dynamic_min_1 = DM_DIG_MIN_NIC;

	//To Initi BT30 igi
	dm_digtable->bt30_cur_igi=0x32;
	dm_digtable->p2p_link_in_progress= false;

	if(rtlefuse->board_type & (ODM_BOARD_EXT_LNA|ODM_BOARD_EXT_PA)) {
		dm_digtable->rx_gain_max = DM_DIG_MAX_NIC;
		dm_digtable->rx_gain_min = DM_DIG_MIN_NIC;
	} else {
		dm_digtable->rx_gain_max = DM_DIG_MAX_NIC;
		dm_digtable->rx_gain_min = DM_DIG_MIN_NIC;
	}

}


void dm_dig(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct false_alarm_statistics *false_alm_cnt = &(rtlpriv->falsealm_cnt);
	struct rtl_efuse *rtlefuse = rtl_efuse(rtl_priv(hw));
	struct rtl_mac *mac = rtl_mac(rtl_priv(hw));
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	// Common parameters
	bool first_connect,first_disconnect;
	u8 dig_maxOfmin, dig_dynamic_min;
	u8 dm_dig_max, dm_dig_min;
	u8 current_igi = dm_digtable->cur_igvalue;
	u8 offset;
	u32 dm_fa_thres[3];
	u8 adap_igi_upper = 0;
	u32 tx_tp = 0, rx_tp = 0;

	// For Ap\ADSL
	bool	dfs_band = false;
	bool	performance = true, bFirstTpTarget = false, first_coverage = false;


	if(dm_dig_abort(hw) == true)
		return;

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_dig()===========================>\n");

	if(dm_adaptivity->adaptivity_flag == true)
		adap_igi_upper = dm_adaptivity->adaptivity_igi_upper;

	//1 Update status

	dig_dynamic_min = dm_digtable->dig_dynamic_min_0;
	first_connect = (rtlpriv->mac80211.link_state == MAC80211_LINKED) && (dm_digtable->media_connect_0 == false);
	first_disconnect = (rtlpriv->mac80211.link_state != MAC80211_LINKED) && (dm_digtable->media_connect_0);


	//1 Boundary Decision
	if(	rtlefuse->board_type & (ODM_BOARD_EXT_LNA | ODM_BOARD_EXT_PA))
	{
		//2 High power case

		dm_dig_max = DM_DIG_MAX_NIC_HP;
		dm_dig_min = DM_DIG_MIN_NIC_HP;
		dig_maxOfmin = DM_DIG_MAX_AP_HP;
	}
	else
	{

		dm_dig_max = DM_DIG_MAX_NIC;
		dm_dig_min = DM_DIG_MIN_NIC;
		dig_maxOfmin = DM_DIG_MAX_AP;

		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Absolutly upper bound = 0x%x, lower bound = 0x%x\n",dm_dig_max,dm_dig_min);

	}


	//1 Adjust boundary by RSSI
	if(rtlpriv->mac80211.link_state == MAC80211_LINKED && performance)
	{
		//2 Modify DIG upper bound

		//4 Modify DIG upper bound for 92E, 8723A\B, 8821 & 8812 BT
		offset = 15;
		if((dm_adaptivity->rssi_min + offset) > dm_dig_max )
			dm_digtable->rx_gain_max = dm_dig_max;
		else if((dm_adaptivity->rssi_min + offset) < dm_dig_min )
			dm_digtable->rx_gain_max = dm_dig_min;
		else
			dm_digtable->rx_gain_max = dm_adaptivity->rssi_min + offset;


		//2 Modify DIG lower bound
		
		
		
		//4 Lower Bound for one entry only
		if(dm_adaptivity->rssi_min < dm_dig_min)
			dig_dynamic_min = dm_dig_min;
		else if (dm_adaptivity->rssi_min > dig_maxOfmin)
			dig_dynamic_min = dig_maxOfmin;
		else
			dig_dynamic_min = dm_adaptivity->rssi_min;


	}
	else
	{

		dm_digtable->rx_gain_max = dm_dig_max;
		dig_dynamic_min = dm_dig_min;
	}
	
	
	
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity->rssi_min=%d\n",dm_adaptivity->rssi_min);



	//1 Modify DIG lower bound, deal with abnormally large false alarm

	if(first_disconnect)
	{
		dm_digtable->rx_gain_min = dig_dynamic_min;
		dm_digtable->forbidden_igi = dig_dynamic_min;
	}
	else
		dm_digtable->rx_gain_min = forbidden_igi_check(hw, dig_dynamic_min, current_igi);


	if(	rtlpriv->link_info.bcn_rx_inperiod < 5)
	{

		if(rtlpriv->mac80211.opmode == NL80211_IFTYPE_STATION &&
			rtlpriv->mac80211.link_state == MAC80211_LINKED)  //STA mode is linked to AP
			dm_digtable->rx_gain_min = dm_dig_min;
	}
	
	if(dm_digtable->rx_gain_min > dm_digtable->rx_gain_max)
		dm_digtable->rx_gain_min = dm_digtable->rx_gain_max;

	//1 False alarm threshold decision
	fa_threshold_check(hw, dfs_band, performance, rx_tp, tx_tp, dm_fa_thres);

	//1 Adjust initial gain by false alarm
	if(rtlpriv->mac80211.link_state == MAC80211_LINKED && performance)
	{
		if(bFirstTpTarget || (first_connect && performance))
		{	
			dm_digtable->large_fa_hit = 0;
			
			{
				if(dm_adaptivity->rssi_min < dig_maxOfmin)
					current_igi = dm_adaptivity->rssi_min;
				else
					current_igi = dig_maxOfmin;
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"igi does on-shot to RSSI value\n");

			}
		}
		else
		{	
			{
				if(false_alm_cnt->cnt_all > dm_fa_thres[2])
					current_igi = current_igi + 4;
				else if (false_alm_cnt->cnt_all > dm_fa_thres[1])
					current_igi = current_igi + 2;
				else if(false_alm_cnt->cnt_all < dm_fa_thres[0])
					current_igi = current_igi - 2;
			}
			
			if((rtlpriv->link_info.bcn_rx_inperiod < 5) && (false_alm_cnt->cnt_all < DM_DIG_FA_TH1))
			{

				if(rtlpriv->mac80211.opmode == NL80211_IFTYPE_STATION &&
					rtlpriv->mac80211.link_state == MAC80211_LINKED)  //STA mode is linked to AP

				{
					current_igi = dm_digtable->rx_gain_min;
					RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Beacon is less than 5 and FA is less than 768, igi GOES TO 0x1E!!!!!!!!!!!!\n");

				}
			}

		}
	}	
	else
	{
		if(first_disconnect || first_coverage)
			current_igi = dm_dig_min;
		else
		{
			if(false_alm_cnt->cnt_all > dm_fa_thres[2])
				current_igi = current_igi + 4;
			else if (false_alm_cnt->cnt_all > dm_fa_thres[1])
				current_igi = current_igi + 2;
			else if(false_alm_cnt->cnt_all < dm_fa_thres[0])
				current_igi = current_igi - 2;
		}
	}

	//1 Check initial gain by upper/lower bound
	if(current_igi < dm_digtable->rx_gain_min)
		current_igi = dm_digtable->rx_gain_min;
	
	if(current_igi > dm_digtable->rx_gain_max)
		current_igi = dm_digtable->rx_gain_max;

	if(dm_adaptivity->support_ability & ODM_BB_ADAPTIVITY && dm_adaptivity->adaptivity_flag == 1)
	{
		if(current_igi > adap_igi_upper)
			current_igi = adap_igi_upper;
		
		if(dm_adaptivity->igi_lower_bound != 0)
		{
			if(current_igi < dm_adaptivity->igi_lower_bound)
				current_igi = dm_adaptivity->igi_lower_bound;
		}

		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"adap_igi_upper = 0x%x \n", adap_igi_upper);
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity->igi_lower_bound = 0x%x\n", dm_adaptivity->igi_lower_bound);
	}
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"linked = %d \n", rtlpriv->mac80211.link_state == MAC80211_LINKED);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"rx_gain_max=0x%x, rx_gain_min=0x%x\n", dm_digtable->rx_gain_max, dm_digtable->rx_gain_min);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"TotalFA=%d\n", false_alm_cnt->cnt_all);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cur_igvalue=0x%x\n", current_igi);

	//1 High power RSSI threshold

	if(dm_adaptivity->bt_hs_operation)
	{
		if(rtlpriv->mac80211.link_state == MAC80211_LINKED)
		{
			if(dm_digtable->bt30_cur_igi > (current_igi))
				dm_write_dig(hw, current_igi);
			else
				dm_write_dig(hw, dm_digtable->bt30_cur_igi);
				
			dm_digtable->media_connect_0 = (rtlpriv->mac80211.link_state == MAC80211_LINKED);
			dm_digtable->dig_dynamic_min_0 = dig_dynamic_min;
		}
		else
		{
			if(mac->link_state == MAC80211_LINKING)
				dm_write_dig(hw, 0x1c);
			else if(dm_adaptivity->bt_connect_process)
				dm_write_dig(hw, 0x28);
			else
				dm_write_dig(hw, dm_digtable->bt30_cur_igi);//dm_write_dig(dm_adaptivity, dm_digtable->cur_igvalue);	
		}
	}	
	else		// BT is not using

	{
		dm_write_dig(hw, current_igi);//dm_write_dig(dm_adaptivity, dm_digtable->cur_igvalue);
		dm_digtable->media_connect_0 = (rtlpriv->mac80211.link_state == MAC80211_LINKED);
		dm_digtable->dig_dynamic_min_0 = dig_dynamic_min;
	}

}

void dm_dig_by_rssi_lps(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct false_alarm_statistics *false_alm_cnt = &(rtlpriv->falsealm_cnt);

	u8	RSSI_Lower=DM_DIG_MIN_NIC;   //0x1E or 0x1C
	u8	current_igi=dm_adaptivity->rssi_min;
	current_igi=current_igi+RSSI_OFFSET_DIG;
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_dig_by_rssi_lps()==>\n");


	// Using FW PS mode to make igi
	//Adjust by  FA in LPS MODE
	if(false_alm_cnt->cnt_all> DM_DIG_FA_TH2_LPS)
		current_igi = current_igi+4;
	else if (false_alm_cnt->cnt_all > DM_DIG_FA_TH1_LPS)
		current_igi = current_igi+2;
	else if(false_alm_cnt->cnt_all < DM_DIG_FA_TH0_LPS)
		current_igi = current_igi-2;	


	//Lower bound checking
	//RSSI Lower bound check
	if((dm_adaptivity->rssi_min-10) > DM_DIG_MIN_NIC)
		RSSI_Lower =(dm_adaptivity->rssi_min-10);
	else
		RSSI_Lower =DM_DIG_MIN_NIC;

	//Upper and Lower Bound checking
	 if(current_igi > DM_DIG_MAX_NIC)
	 	current_igi=DM_DIG_MAX_NIC;
	 else if(current_igi < RSSI_Lower)
		current_igi =RSSI_Lower;

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"false_alm_cnt->cnt_all = %d\n",false_alm_cnt->cnt_all);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_adaptivity->rssi_min = %d\n",dm_adaptivity->rssi_min);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"current_igi = 0x%x\n",current_igi);


	dm_write_dig(hw, current_igi);

}

void dig_for_bt_hs_mode(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;
	u8					dig_for_bt_hs=0;
	u8					dig_up_bound=0x5a;
	if(dm_adaptivity->bt_connect_process)
			dig_for_bt_hs = 0x22;
	else
	{
		/*Decide DIG value by BT HS RSSI.*/
		dig_for_bt_hs = dm_adaptivity->bt_hs_rssi+4;
		//DIG Bound

		if(dig_for_bt_hs > dig_up_bound)
			dig_for_bt_hs = dig_up_bound;
		if(dig_for_bt_hs < 0x1c)
			dig_for_bt_hs = 0x1c;

		// update Current igi
		dm_digtable->bt30_cur_igi = dig_for_bt_hs;
	}
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dig_for_bt_hs_mode() : set DigValue=0x%x\n", dig_for_bt_hs);

}

void fa_threshold_check(struct ieee80211_hw *hw,bool dfs_band,bool performance,u32 rx_tp,u32 tx_tp,u32* dm_fa_thres)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);

	if(rtlpriv->mac80211.link_state == MAC80211_LINKED && (performance||dfs_band))
	{
		// For NIC
		dm_fa_thres[0] = DM_DIG_FA_TH0;
		dm_fa_thres[1] = DM_DIG_FA_TH1;
		dm_fa_thres[2] = DM_DIG_FA_TH2;
	}
	else
	{
		dm_fa_thres[0] = 2000;
		dm_fa_thres[1] = 4000;
		dm_fa_thres[2] = 5000;

	}
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_fa_thres = %d, %d, %d \n", dm_fa_thres[0], dm_fa_thres[1], dm_fa_thres[2]);

	return;
}

u8 forbidden_igi_check(struct ieee80211_hw *hw,u8	dig_dynamic_min,u8	current_igi)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct false_alarm_statistics *false_alm_cnt = &(rtlpriv->falsealm_cnt);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;
	u8	rx_gain_min = dm_digtable->rx_gain_min;


	if(false_alm_cnt->cnt_all > 10000)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Abnormally false alarm case. \n");


		if(dm_digtable->large_fa_hit != 3)
			dm_digtable->large_fa_hit++;

		if(dm_digtable->forbidden_igi < current_igi)//if(dm_digtable->forbidden_igi < dm_digtable->cur_igvalue)
		{
			dm_digtable->forbidden_igi = current_igi;//dm_digtable->forbidden_igi = dm_digtable->cur_igvalue;
			dm_digtable->large_fa_hit = 1;
		}
		if(dm_digtable->large_fa_hit >= 3)
		{
			if((dm_digtable->forbidden_igi + 2) > dm_digtable->rx_gain_max)
				rx_gain_min = dm_digtable->rx_gain_max;
			else
				rx_gain_min = (dm_digtable->forbidden_igi + 2);
			dm_digtable->recover_cnt = 1800;
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Abnormally false alarm case: recover_cnt = %d \n", dm_digtable->recover_cnt);

		}
	}
	else
	{
		if(dm_digtable->recover_cnt != 0)
			dm_digtable->recover_cnt --;
		else
		{
			if(dm_digtable->large_fa_hit < 3)
			{
				if((dm_digtable->forbidden_igi - 2) < dig_dynamic_min) {
					dm_digtable->forbidden_igi = dig_dynamic_min; //DM_DIG_MIN;
					rx_gain_min = dig_dynamic_min; //DM_DIG_MIN;
					RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_dig(): Normal Case: At Lower Bound\n");

				} else {
					dm_digtable->forbidden_igi -= 2;
					rx_gain_min = (dm_digtable->forbidden_igi + 2);
					RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_dig(): Normal Case: Approach Lower Bound\n");

				}
			} else {
				dm_digtable->large_fa_hit = 0;
			}
		}
	}

	return rx_gain_min;

}

void dm_in_band_noise_calculate (struct ieee80211_hw *hw)
{
	return;
}

void dm_reset_fa_counter_92c(struct ieee80211_hw *hw)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);

//	PADAPTER		pAdapter	= pDM_Odm->Adapter;
	u8	BBReset;

	//reset false alarm counter registers
	rtl_set_bbreg(hw, 0xd00, BIT(27), 1);
	rtl_set_bbreg(hw, 0xd00, BIT(27), 0);
	//update ofdm counter
	rtl_set_bbreg(hw, 0xc00, BIT(31), 0); //update page C counter
	rtl_set_bbreg(hw, 0xd00, BIT(31), 0); //update page D counter

	//reset CCK CCA counter
	rtl_set_bbreg(hw, 0xa2c, BIT(13)|BIT(12), 0);
	rtl_set_bbreg(hw, 0xa2c, BIT(13)|BIT(12), 2);
	//reset CCK FA counter
	rtl_set_bbreg(hw, 0xa2c, BIT(15)|BIT(14), 0);
	rtl_set_bbreg(hw, 0xa2c, BIT(15)|BIT(14), 2);

	//BB Reset
	if(rtlpriv->mac80211.link_state != MAC80211_LINKED)
	{
		rtl_set_bbreg(hw, 0x87C, BIT(31), 1); //clock gated to prevent from AGC table mess 
		BBReset = rtl_read_byte(rtlpriv, 0x02);
		rtl_write_byte(rtlpriv, 0x02, BBReset&(~BIT(0)));
		rtl_write_byte(rtlpriv, 0x02, BBReset|BIT(0));
		rtl_set_bbreg(hw, 0x87C, BIT(31), 0);
	}


}

//3============================================================
//3 FASLE ALARM CHECK
//3============================================================

void dm_false_alarm_counter_statistics(struct ieee80211_hw *hw)
{
	u32 						ret_value;
	
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct false_alarm_statistics *false_alm_cnt = &(rtlpriv->falsealm_cnt);

	if(!(dm_adaptivity->support_ability & ODM_BB_FA_CNT))
		return;


	//hold ofdm counter
	rtl_set_bbreg(hw, ODM_REG_OFDM_FA_HOLDC_11N, BIT(31), 1);//hold page C counter
	rtl_set_bbreg(hw, ODM_REG_OFDM_FA_RSTD_11N, BIT(31), 1);//hold page D counter

	ret_value = rtl_get_bbreg(hw, ODM_REG_OFDM_FA_TYPE1_11N, MASKDWORD);

	false_alm_cnt->cnt_fast_fsync_fail = (ret_value&0xffff);
	false_alm_cnt->cnt_sb_search_fail = ((ret_value&0xffff0000)>>16);		

	
	ret_value = rtl_get_bbreg(hw, ODM_REG_OFDM_FA_TYPE2_11N, MASKDWORD);
	false_alm_cnt->cnt_ofdm_cca = (ret_value&0xffff); 
	false_alm_cnt->cnt_parity_fail = ((ret_value&0xffff0000)>>16);	

	
	ret_value = rtl_get_bbreg(hw, ODM_REG_OFDM_FA_TYPE3_11N, MASKDWORD);

	false_alm_cnt->cnt_rate_illegal = (ret_value&0xffff);
	false_alm_cnt->cnt_crc8_fail = ((ret_value&0xffff0000)>>16);

	
	ret_value = rtl_get_bbreg(hw, ODM_REG_OFDM_FA_TYPE4_11N, MASKDWORD);
	false_alm_cnt->cnt_mcs_fail = (ret_value&0xffff);

	false_alm_cnt->cnt_ofdm_fail = 	false_alm_cnt->cnt_parity_fail + false_alm_cnt->cnt_rate_illegal +
							false_alm_cnt->cnt_crc8_fail + false_alm_cnt->cnt_mcs_fail +
							false_alm_cnt->cnt_fast_fsync_fail + false_alm_cnt->cnt_sb_search_fail;

	//hold cck counter
	rtl_set_bbreg(hw, ODM_REG_CCK_FA_RST_11N, BIT(12), 1);
	rtl_set_bbreg(hw, ODM_REG_CCK_FA_RST_11N, BIT(14), 1);

	ret_value = rtl_get_bbreg(hw, ODM_REG_CCK_FA_LSB_11N, MASK_BYTE0);
	false_alm_cnt->cnt_cck_fail = ret_value;

	
	ret_value = rtl_get_bbreg(hw, ODM_REG_CCK_FA_MSB_11N, MASK_BYTE3);
	false_alm_cnt->cnt_cck_fail +=  (ret_value& 0xff)<<8;

	
	ret_value = rtl_get_bbreg(hw, ODM_REG_CCK_CCA_CNT_11N, MASKDWORD);
	false_alm_cnt->cnt_cck_cca = ((ret_value&0xFF)<<8) |((ret_value&0xFF00)>>8);


	false_alm_cnt->cnt_all = (false_alm_cnt->cnt_fast_fsync_fail + 
						false_alm_cnt->cnt_sb_search_fail +
						false_alm_cnt->cnt_parity_fail +
						false_alm_cnt->cnt_rate_illegal +
						false_alm_cnt->cnt_crc8_fail +
						false_alm_cnt->cnt_mcs_fail +
						false_alm_cnt->cnt_cck_fail);	

	false_alm_cnt->cnt_cca_all = false_alm_cnt->cnt_ofdm_cca + false_alm_cnt->cnt_cck_cca;

	dm_reset_fa_counter_92c(hw);
		
		
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Enter dm_false_alarm_counter_statistics\n");
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cnt_fast_fsync_fail=%d, cnt_sb_search_fail=%d\n",false_alm_cnt->cnt_fast_fsync_fail, false_alm_cnt->cnt_sb_search_fail);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cnt_parity_faul=%d, cnt_rate_illegal=%d\n",false_alm_cnt->cnt_parity_fail, false_alm_cnt->cnt_rate_illegal);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cnt_crc8_fail=%d, cnt_mcs_fail=%d\n",false_alm_cnt->cnt_crc8_fail, false_alm_cnt->cnt_mcs_fail);



	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cnt_cck_fail=%d\n",	false_alm_cnt->cnt_cck_fail);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"cnt_ofdm_fail=%d\n",	false_alm_cnt->cnt_ofdm_fail);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Total False Alarm=%d\n",	false_alm_cnt->cnt_all);

}

//3============================================================
//3 CCK Packet Detect Threshold
//3============================================================

void dm_pause_cck_packet_detection(struct ieee80211_hw *hw,ODM_Pause_CCKPD_TYPE	pause_type,u8 CCKPDThreshold)
{
	static	bool		paused = false;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_pause_cck_packet_detection()=========>\n");
	if(dm_digtable->p2p_link_in_progress)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"P2P in progress !!\n");

		return;
	}
	if(!paused && (!(dm_adaptivity->support_ability & ODM_BB_CCK_PD) || !(dm_adaptivity->support_ability & ODM_BB_FA_CNT)))
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Return: support_ability ODM_BB_CCK_PD or ODM_BB_FA_CNT is disabled\n");

		return;
	}

	switch(pause_type)
	{
		//1 Pause CCK Packet Detection Threshold
		case ODM_PAUSE_CCKPD:
			//2 Disable DIG
			dm_cmn_info_update(hw, ODM_CMNINFO_ABILITY, dm_adaptivity->support_ability & (~ODM_BB_CCK_PD));
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Pause CCK packet detection threshold !!\n");


			//2 Backup CCK Packet Detection Threshold value
			if(!paused)
			{
				dm_digtable->cck_pd_backup = dm_digtable->cur_cck_cca_thres;
				paused = true;
			}
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Backup CCK packet detection tgreshold  = %d\n", dm_digtable->cck_pd_backup);


			//2 Write new CCK Packet Detection Threshold value
			dm_write_cck_cca_thres(hw, CCKPDThreshold);
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Write new CCK packet detection tgreshold = %d\n", CCKPDThreshold);
			break;
			
		//1 Resume CCK Packet Detection Threshold
		case ODM_RESUME_CCKPD:
			if(paused)
			{
				//2 Write backup CCK Packet Detection Threshold value
				dm_write_cck_cca_thres(hw, dm_digtable->cck_pd_backup);
				paused = false;
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Write original CCK packet detection tgreshold = %d\n", dm_digtable->cck_pd_backup);

				//2 Enable CCK Packet Detection Threshold
				dm_cmn_info_update(hw, ODM_CMNINFO_ABILITY, dm_adaptivity->support_ability | ODM_BB_CCK_PD);		
				RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Resume CCK packet detection threshold  !!\n");
			}
			break;
			
		default:
			RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"Wrong  type !!\n");
			break;
	}	
	return;
}


void  dm_cck_packet_detection_thresh(struct ieee80211_hw *hw)
{
	u8						cur_cck_cca_thres;
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct false_alarm_statistics *false_alm_cnt = &(rtlpriv->falsealm_cnt);

	if(dm_adaptivity->bt_hs_operation)
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_cck_packet_detection_thresh() write 0xcd for BT HS mode!!\n");

		dm_write_cck_cca_thres(hw, 0xcd);
		return;
	}

	if((!(dm_adaptivity->support_ability & ODM_BB_CCK_PD)) ||(!(dm_adaptivity->support_ability & ODM_BB_FA_CNT)))
	{
		RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_cck_packet_detection_thresh()  return==========\n");
		return;
	}
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_cck_packet_detection_thresh()  ==========>\n");


	if(rtlpriv->mac80211.link_state == MAC80211_LINKED) {
		if(dm_adaptivity->rssi_min > 25)
			cur_cck_cca_thres = 0xcd;
		else if((dm_adaptivity->rssi_min <= 25) && (dm_adaptivity->rssi_min > 10))
			cur_cck_cca_thres = 0x83;
		else
		{
			if(false_alm_cnt->cnt_cck_fail > 1000)
				cur_cck_cca_thres = 0x83;
			else
				cur_cck_cca_thres = 0x40;
		}
	} else {
		if(false_alm_cnt->cnt_cck_fail > 1000)
			cur_cck_cca_thres = 0x83;
		else
			cur_cck_cca_thres = 0x40;
	}

	dm_write_cck_cca_thres(hw, cur_cck_cca_thres);
	RT_TRACE(rtlpriv, COMP_DIG, DBG_TRACE,"dm_cck_packet_detection_thresh()  cur_cck_cca_thres = 0x%x\n",cur_cck_cca_thres);

}

void dm_write_cck_cca_thres(struct ieee80211_hw *hw,u8 cur_cck_cca_thres)
{
	struct rtl_priv *rtlpriv = rtl_priv(hw);
	struct dig_t *dm_digtable = &rtlpriv->dm_digtable;

	if(dm_digtable->cur_cck_cca_thres!=cur_cck_cca_thres)		//modify by Guo.Mingzhi 2012-01-03
	{
		rtl_write_byte(rtlpriv, ODM_REG_CCK_CCA_11N , cur_cck_cca_thres);
	}
	dm_digtable->pre_cck_cca_thres = dm_digtable->cur_cck_cca_thres;
	dm_digtable->cur_cck_cca_thres = cur_cck_cca_thres;
}


void  dm_cmn_info_update(struct ieee80211_hw *hw,u32 cmn_info,u32 value)
{
	//
	// This init variable may be changed in run time.
	//
	switch	(cmn_info)
	{
	case	ODM_CMNINFO_ABILITY:
				dm_adaptivity->support_ability = (u32)value;
			break;
	default:
			//do nothing
			break;
	}

	
}


